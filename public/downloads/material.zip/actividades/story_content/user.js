function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6jQeDPNOWLM":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

